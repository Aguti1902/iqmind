Certificados

1 - https://iqmind-git-main-nexgents-projects.vercel.app
    + URL que debe ser accesible a Internet publicamente como minimo a los dominios de Apple para pueda verificar el certificado: https://iqmind-git-main-nexgents-projects.vercel.app/.well-known/apple-developer-merchantid-domain-association.txt
